/**
 *
 */
/**     arco_run.js
#
#      Copyright  (C) 2016 Jia Liu <liujia@iscas.ac.cn>
#
#      This program is free software; you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program; if not, write to the Free Software
#      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#      MA 02110-1301, USA.
*/
var type_name_list = new Array();
var type_list = new Array();
var f_type_name_list = new Array();
var f_type_list = new Array();
var pname;
var version;
var blk_list = new Array();
var component_list = new Array();
var connection_list = new Array();
var rule_list = new Array();
var notimeout_list = new Array();
var for_id = 0;
var while_id = 0;
var until_id = 0;
var delay_id = 0;
var timeout_id = 0;
var and_id = 0;
var or_id = 0;
var branch_id = 0;
var button_id = 0;
var led_id = 0;
var pir_id = 0;
var switch_id = 0;
var relay_id = 0;
var probe_id = 0;
var textgen_id = 0;
var blk_ind_info = new Object();
var abr_list = new Array();
var led_info = new Object();
var switch_info = new Object();
var relay_info = new Object();
var button_info = new Object();
var pir_info = new Object();
var probe_info = new Object();
var textgen_info = new Object();
var blk_begin = new Array();
var blk_end = new Array();
var  complie_info="";
f_type_name_list = ["led", "switch", "relay", "pir", "button", "probe", "textgen", "ForTrigger", "ForInit", "ForInput", "ForCmp", "ForCnt", "ForBack", "ForEnd", "ForCntBack", "text_print_delay", "UntilBack", "UntilEnd", "WhileStart", "WhileBack", "WhileEnd", "WhileFinish", "AndFinish", "OrFinish"];
f_type_list = ["LED", "SWITCH", "RELAY", "PIR", "BUTTON", "Probe", "TextGen", "Trigger", "VDev", "InputFilter", "Zero", "Countdown", "Positive", "Zero", "Positive", "VDev", "UntilBack", "UntilEnd", "WhileStart", "WhileBack", "WhileEnd", "WhileFinish", "VDev", "VDev"];
//f_type_list = ["LED"];
type_name_list = ["probe", "textgen", "led", "switch", "relay", "pir", "button", "controls_and", "controls_or", "controls_repeat_for", "controls_repeat_until", "controls_repeat_while", "text_print_timeout", "text_print_delay", "controls_branch"];
blk_type = ["6", "1", "4", "3", "2", "1", "1", "1", "1", "6", "6", "6", "7", "2", "6"];
function arco_run() {
	pname = "aaa";
	version = "0.0.1";
	// pname = document.getElementsByName("pname")[0].value;
	// version = document.getElementsByName("version")[0].value;
	ui_read(blk_list);
	var erorr_num = blk_list_check(blk_list, notimeout_list, blk_ind_info, abr_list);
	if (erorr_num == 0) {
		var cdl_data = cdl_gen(abr_list); //生成cdlxml内容
		alert(cdl_data);
		alert(blk_begin);
		alert(blk_end);
		//雨霖的代码

		//调田谞的代码
		var dgl_result = generate_ddl(cdl_data);
		alert(dgl_result.graph);
		alert(dgl_result.member);
		alert(dgl_result["handler.py"]);
		//publish(pname, version, "cat0", "arco-dgl", "test", dgl_result, uid, key, onerror);
	}

}

function ui_read(blk_list) {

	var xmldoc = Blockly.Xml.workspaceToDom(Blockly.mainWorkspace);
	for (var i = 0; i < xmldoc.childNodes.length; i++) {
		var list_obj = new Object();
		list_obj.blklist = new Array();
		list_obj.blkvallist = new Array();
		var b_element = xmldoc.childNodes[i]; //block节点
		var result = parse_element(b_element, list_obj);
		blk_list.push(list_obj);
		alert(blk_list[i].blklist);
	}
	return blk_list;

}

function dev_type_match(blk_name) {
	var operation_name = blk_name;
	if (operation_name.indexOf("ID") >= 0) {
		var name_split = operation_name.split("ID");
		operation_name = name_split[0];
	}

	var result = "";
	for (var i = 0; i < f_type_name_list.length; i++) {
		if (operation_name == f_type_name_list[i]) {
			result = f_type_list[i];

		}
	}
	return result;

}

function ui_type_match(blk_name) {
	var operation_name = blk_name;
	if (operation_name.indexOf("ID") >= 0) {
		var name_split = operation_name.split("ID");
		operation_name = name_split[0];
	}
	var result = "";
	for (var i = 0; i < type_name_list.length; i++) {
		if (operation_name == type_name_list[i]) {
			result = blk_type[i];

		}
	}
	return result;

}

function orfinish_next_match(blk_namea, blk_nameb) {
	var orfinish_a = blk_namea;
	var orfinish_b = blk_nameb;
	var next_a;
	var next_b;
	var result;
	for (var i = 0; i < component_list.length; i++) {
		if (orfinish_a == component_list[i].name) {
			next_a = component_list[i].next;

		} else if (orfinish_b == component_list[i].name) {
			next_b = component_list[i].next;

		}
	}
	if (next_a == next_b) {
		result = 1;
	}
	return result;

}

function andfinish_from_match(andfinish_a) {
	var andfinish_a = andfinish_a;
	var andfrom_a;
	var result;

	for (var i = 0; i < connection_list.length; i++) {
		if (connection_list[i].from.length == 1 && connection_list[i].from[0] == andfinish_a) {
			result = i; //to为andfinisha的fromlist
		}
	}

	return result;

}

function cmp_type_match(blk_name) {
	var operation_name = blk_name;
	var result = "";
	for (var i = 0; i < blk_begin.length; i++) {
		if (operation_name == blk_begin[i]) {
			result = "sc";

		}
	}
	for (var i = 0; i < blk_end.length; i++) {
		if (operation_name == blk_end[i]) {
			result = "tc";
		}
	}
	if (blk_name.indexOf("ForTrigger") >= 0) {
		result = "sc";
	}
	return result;
}
