global.webduino = require('webduino-js');
require('./webduino-blockly')(global);
