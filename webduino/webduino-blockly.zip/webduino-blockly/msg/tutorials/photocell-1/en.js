MSG.title = "Webduino Blockly Chapter 12-1 : Photocell";
MSG.subTitle = "Chapter 12-1 : Photocell";
MSG.demoDescription = "Use photoresistors, return values.";
