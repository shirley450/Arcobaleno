MSG.title = "Webduino Blockly 課程 12-1：控制光敏電阻";
MSG.subTitle = "課程 12-1：控制光敏電阻";
MSG.demoDescription = "控制光敏電阻，回傳數值";
