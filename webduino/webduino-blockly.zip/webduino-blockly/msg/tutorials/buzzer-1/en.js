MSG.title = "Webduino Blockly Chapter 9-1 : Buzzer";
MSG.subTitle = "Chapter 9-1 : Buzzer";
MSG.demoDescription = "Create a music and display notes and tempos, play this music by buzzer";
MSG.notes = "Notes:";
MSG.tempos = "Tempos:";
