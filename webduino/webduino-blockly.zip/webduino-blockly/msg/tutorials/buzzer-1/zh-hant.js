MSG.title = "Webduino Blockly 課程 9-1：蜂鳴器播放音樂";
MSG.subTitle = "課程 9-1：蜂鳴器播放音樂";
MSG.demoDescription = "製作一首音樂並用蜂鳴器播放，將音樂簡譜顯示在下方";
MSG.notes = "音符：";
MSG.tempos = "節奏：";
