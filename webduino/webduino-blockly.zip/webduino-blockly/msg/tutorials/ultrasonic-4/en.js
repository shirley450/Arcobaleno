MSG.title = "Webduino Blockly Chapter 3-4 : Ultrasonic and RGB LED";
MSG.subTitle = "Chapter 3-4 : Ultrasonic and RGB LED";
MSG.demoDescription = "Using Ultrasonic sensors, control RGB LED";
