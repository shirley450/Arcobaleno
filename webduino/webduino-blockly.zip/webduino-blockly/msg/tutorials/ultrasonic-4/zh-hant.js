MSG.title = "Webduino Blockly 課程 3-4：超音波傳感器控制三色 LED 燈顏色";
MSG.subTitle = "課程 3-4：超音波傳感器控制三色 LED 燈顏色";
MSG.demoDescription = "使用超音波傳感器，控制三色 LED 燈的顏色變化，並將顏色顯示在下方區域裡";
