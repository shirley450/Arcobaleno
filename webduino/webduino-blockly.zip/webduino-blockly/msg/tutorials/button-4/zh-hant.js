MSG.title = "Webduino Blockly 課程 4-4：點擊按鈕開關玩賽跑小遊戲";
MSG.subTitle = "課程 4-4：點擊按鈕開關玩賽跑小遊戲";
MSG.demoDescription = "使用按鈕開關和電腦進行賽跑";
