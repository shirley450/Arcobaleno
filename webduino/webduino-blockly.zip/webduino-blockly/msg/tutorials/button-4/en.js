MSG.title = "Webduino Blockly Chapter 4-4 : Click button to play game";
MSG.subTitle = "Chapter 4-4 : Click button to play game";
MSG.demoDescription = "Run with NPC";
