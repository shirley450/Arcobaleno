MSG.title = "Webduino Blockly 課程 6-1：偵測人體紅外線";
MSG.subTitle = "課程 6-1：偵測人體紅外線";
MSG.demoDescription = "偵測到人體紅外線變化時，讓圖片的燈泡發亮";
