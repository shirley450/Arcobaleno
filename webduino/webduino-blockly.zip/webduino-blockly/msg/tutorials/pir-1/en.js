MSG.title = "Webduino Blockly Chapter 6-1 : PIR";
MSG.subTitle = "Chapter 6-1 : PIR";
MSG.demoDescription = "If it detects human infra-red change light bulb glows";
