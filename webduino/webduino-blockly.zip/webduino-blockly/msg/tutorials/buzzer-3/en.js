MSG.title = "Webduino Blockly Chapter 9-3 : Buzzer and Change music";
MSG.subTitle = "Chapter 9-3 : Buzzer and Change music";
MSG.demoDescription = "Change music and play this music by buzzer";
