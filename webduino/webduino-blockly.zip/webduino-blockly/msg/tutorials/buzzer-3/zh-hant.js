MSG.title = "Webduino Blockly 課程 9-3：切換音樂，用蜂鳴器播放";
MSG.subTitle = "課程 9-3：切換音樂，用蜂鳴器播放";
MSG.demoDescription = "點選下方按鈕切換不同的音樂";

