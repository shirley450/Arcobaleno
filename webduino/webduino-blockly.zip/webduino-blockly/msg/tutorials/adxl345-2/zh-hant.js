MSG.title = "Webduino Blockly 課程 14-2：旋轉角度旋轉圖片";
MSG.subTitle = "課程 14-2：旋轉角度旋轉圖片";
MSG.demoDescription = "控制三軸加速度計，回傳旋轉數值，並旋轉圖片";
