MSG.title = "Webduino Blockly Chapter 14-2 : Rotate Picture";
MSG.subTitle = "Chapter 14-2 : Rotate Picture";
MSG.demoDescription = "Tri-axis accelerometer, returned rotation value, and rotate the picture.";
