MSG.title = "Webduino Blockly Chapter 9-4 : Buzzer ( play, stop, pause )";
MSG.subTitle = "Chapter 9-4 : Buzzer ( play, stop, pause )";
MSG.demoDescription = "Click on a button, let the buzzer has play, pause and stop the three functions and status is displayed at the bottom";
