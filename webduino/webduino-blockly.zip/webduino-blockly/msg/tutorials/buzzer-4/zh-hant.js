MSG.title = "Webduino Blockly 課程 9-4：蜂鳴器的播放、暫停、停止 ( 按鈕開關控制 )";
MSG.subTitle = "課程 9-4：蜂鳴器的播放、暫停、停止 ( 按鈕開關控制 )";
MSG.demoDescription = "利用一顆按鈕開關，做出蜂鳴器音樂播放、暫停與停止的三種功能，並將狀態顯示在下方";

