MSG.title = "Webduino Blockly 課程 2-1：三色 LED 燈";
MSG.subTitle = "課程 2-1：三色 LED 燈";
MSG.demoDescription = "點亮三色 LED 燈，並將對應的顏色顯示在區域裡";
