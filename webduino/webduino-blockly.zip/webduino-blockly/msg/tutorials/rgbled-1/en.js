MSG.title = "Webduino Blockly Chapter 2-1 : RGB LED";
MSG.subTitle = "Chapter 2-1 : RGB LED";
MSG.demoDescription = "Lighted RGB LED, and displays color in area";
