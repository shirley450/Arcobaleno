MSG.title = "Webduino Blockly Chapter 5-3: Read and write dht data";
MSG.subTitle = "Chapter 5-3: Read and write dht data";
MSG.demoDescription = "Use Firebase, read and write dht data";
MSG.temperature = "temperature: ";
MSG.humidity = "humidity: ";
