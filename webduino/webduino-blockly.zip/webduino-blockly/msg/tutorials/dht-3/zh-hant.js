MSG.title = "Webduino Blockly 課程 5-3：使用 Firebase 紀錄溫濕度數值";
MSG.subTitle = "課程 5-3：使用 Firebase 紀錄溫濕度數值";
MSG.demoDescription = "使用 firebase 作為資料庫，儲存溫度與濕度數值。";
MSG.temperature = "溫度：";
MSG.humidity = "濕度：";
