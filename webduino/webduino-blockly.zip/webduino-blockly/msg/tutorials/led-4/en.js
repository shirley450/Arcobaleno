MSG.title = "Webduino Blockly Chapter 1-4 : Two blinking LED";
MSG.timerVariable = "timer";
MSG.subTitle = "Chapter 1-4 : Two blinking LED";
MSG.demoDescription = "Click on the light bulb, let the two LED start blinking and stops blinking";
