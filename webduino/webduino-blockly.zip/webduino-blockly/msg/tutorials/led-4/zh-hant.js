MSG.title = "Webduino Blockly 課程 1-4：兩顆 LED 燈交互閃爍";
MSG.timerVariable = "計時器";
MSG.subTitle = "課程 1-4：兩顆 LED 燈交互閃爍";
MSG.demoDescription = "利用燈泡圖片作為開關，讓兩顆 LED 開始閃爍與停止閃爍";
