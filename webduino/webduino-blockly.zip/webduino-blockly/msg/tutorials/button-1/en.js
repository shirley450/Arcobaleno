MSG.title = "Webduino Blockly Chapter 4-1 : Button";
MSG.subTitle = "Chapter 4-1 : Button";
MSG.demoDescription = "Detect button signal and displayed in the area below.";
