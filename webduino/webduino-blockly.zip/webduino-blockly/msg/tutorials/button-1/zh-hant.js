MSG.title = "Webduino Blockly 課程 4-1：按鈕開關";
MSG.subTitle = "課程 4-1：按鈕開關";
MSG.demoDescription = "偵測按鈕開關點擊的訊號，並顯示在下方區域。";
