MSG.title = "Webduino Blockly Chapter 1-1 : LED ON";
MSG.subTitle = "Chapter 1-1 : LED ON";
MSG.demoDescription = "Using blocks, light LED and bulb pictures";
