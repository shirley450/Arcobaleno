MSG.title = "Webduino Blockly 課程 1-1：點亮 LED 燈";
MSG.subTitle = "課程 1-1：點亮 LED 燈";
MSG.demoDescription = "點亮 LED 燈與下面這張圖片的燈泡";
