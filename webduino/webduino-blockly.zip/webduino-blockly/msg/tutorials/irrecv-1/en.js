MSG.title = "Webduino Blockly Chapter 15-1 : Receive infrared signals";
MSG.subTitle = "Chapter 15-1 : Receive infrared signals";
MSG.demoDescription = "Receive infra-red signals, the code displayed below.";
