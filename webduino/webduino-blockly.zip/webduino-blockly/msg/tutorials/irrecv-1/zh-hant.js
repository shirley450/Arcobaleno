MSG.title = "Webduino Blockly 課程 15-1：接收紅外線訊號";
MSG.subTitle = "課程 15-1：接收紅外線訊號";
MSG.demoDescription = "接收紅外線訊號，將代碼顯示在下方";
