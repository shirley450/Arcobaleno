MSG.title = "Webduino Blockly 課程 15-3：紅外線遙控 youtube 播放";
MSG.subTitle = "課程 15-3：紅外線遙控 youtube 播放";
MSG.demoDescription = "接收紅外線訊號，遙控 youtube 播放";
