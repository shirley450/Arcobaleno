MSG.title = "Webduino Blockly Chapter 15-3 : Youtube";
MSG.subTitle = "Chapter 15-3 : Youtube";
MSG.demoDescription = "Infrared remote control YouTube playback.";
