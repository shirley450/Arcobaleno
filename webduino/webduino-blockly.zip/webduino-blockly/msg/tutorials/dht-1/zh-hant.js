MSG.title = "Webduino Blockly 課程 5-1：溫濕度傳感器";
MSG.subTitle = "課程 5-1：溫濕度傳感器";
MSG.demoDescription = "使用溫濕度傳感器，回傳並顯示當前的溫度與濕度";
MSG.temperature = "溫度：";
MSG.humidity = "濕度：";
