MSG.title = "Webduino Blockly Chapter 5-1: DHT";
MSG.subTitle = "Chapter 5-1: DHT";
MSG.demoDescription = "Use DHT sensor, return and displays the current temperature and humidity.";
MSG.temperature = "temperature: ";
MSG.humidity = "humidity: ";
