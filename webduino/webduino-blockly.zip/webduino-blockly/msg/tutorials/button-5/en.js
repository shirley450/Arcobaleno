MSG.title = "Webduino Blockly Chapter 4-5 : Click button to control youtube";
MSG.subTitle = "Chapter 4-5 : Click button to control youtube";
MSG.demoDescription = "Click button to control youtube play, stop and pause.";
