MSG.title = "Webduino Blockly 課程 4-5：點擊按鈕開關控制 Youtube";
MSG.subTitle = "課程 4-5：點擊按鈕開關控制 Youtube";
MSG.demoDescription = "點擊按鈕開關控制 Youtube 的播放、暫停和停止";
