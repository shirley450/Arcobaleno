MSG.title = "Webduino Blockly Chapter 10-2 : Shock button to add number";
MSG.subTitle = "Chapter 10-2 : Shock button to add number";
MSG.demoDescription = "Shock button to make the numbers plus 1.";
