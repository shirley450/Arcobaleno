MSG.title = "Webduino Blockly 課程 10-1：震動開關增加數字";
MSG.subTitle = "課程 10-1：震動開關增加數字";
MSG.demoDescription = "每次晃動震動開關時讓數字加 1。";
