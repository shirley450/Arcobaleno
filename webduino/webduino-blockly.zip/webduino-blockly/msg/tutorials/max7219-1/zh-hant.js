MSG.title = "Webduino Blockly 課程 13-1：點矩陣顯示圖形";
MSG.subTitle = "課程 13-1：點矩陣顯示圖形";
MSG.demoDescription = "利用點矩陣顯示圖形，可以點選下面的連結產生圖形代碼";
