MSG.title = "Webduino Blockly Chapter 13-1 : Matrix display graphics";
MSG.subTitle = "Chapter 13-1 : Matrix display graphics";
MSG.demoDescription = "Use dot matrix display graphics, you can click on the following link graphic codes.";
