MSG.title = "Webduino Blockly Chapter 3-2 : UltraSonic change image size";
MSG.subTitle = "Chapter 3-2 : UltraSonic change image size";
MSG.demoDescription = "Using Ultrasonic sensor, changing picture size.";
