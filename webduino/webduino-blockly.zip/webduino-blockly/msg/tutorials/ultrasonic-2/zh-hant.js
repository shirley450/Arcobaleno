MSG.title = "Webduino Blockly 課程 3-2：超音波傳感器改變圖片大小";
MSG.subTitle = "課程 3-2：超音波傳感器改變圖片大小";
MSG.demoDescription = "使用超音波傳感器改變下面這張圖片的大小，並顯示數值";
