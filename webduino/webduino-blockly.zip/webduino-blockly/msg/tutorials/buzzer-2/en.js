MSG.title = "Webduino Blockly Chapter 9-2 : Buzzer";
MSG.subTitle = "Chapter 9-2 : Buzzer";
MSG.demoDescription = "Create a music and play this music by buzzer";
