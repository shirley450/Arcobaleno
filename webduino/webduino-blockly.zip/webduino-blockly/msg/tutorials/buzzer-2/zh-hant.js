MSG.title = "Webduino Blockly 課程 9-2：蜂鳴器播放音樂";
MSG.subTitle = "課程 9-2：蜂鳴器播放音樂";
MSG.demoDescription = "嘗試用其他的方式製作一首音樂，並用蜂鳴器播放";

