MSG.title = "Webduino Blockly 課程 4-2：點擊按鈕開關增加數字";
MSG.subTitle = "課程 4-2：點擊按鈕開關增加數字";
MSG.demoDescription = "每次點擊按鈕開關時讓數字加 1。";
