MSG.title = "Webduino Blockly Chapter 4-2 : Click button to add number";
MSG.subTitle = "Chapter 4-2 : Click button to add number";
MSG.demoDescription = "Per-click button to make the numbers plus 1.";
