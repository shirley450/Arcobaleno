MSG.title = "Webduino Blockly hapter 2-2：Change RGB LED Color";
MSG.subTitle = "Chapter 2-2：Change RGB LED Color";
MSG.demoDescription = "Click on the button, switch the RGB LED color";
