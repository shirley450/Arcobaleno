MSG.title = "Webduino Blockly 課程 2-2：三色 LED 燈切換顏色";
MSG.subTitle = "課程 2-2：三色 LED 燈切換顏色";
MSG.demoDescription = "點選按鈕，切換三色 LED 燈的顏色";
