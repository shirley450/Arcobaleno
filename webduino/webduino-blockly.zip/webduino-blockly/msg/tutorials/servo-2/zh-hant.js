MSG.title = "Webduino Blockly 課程 8-2：使用按鈕開關控制伺服馬達";
MSG.subTitle = "課程 8-2：使用按鈕開關控制伺服馬達";
MSG.demoDescription = "點選按鈕開關讓伺服馬達旋轉，在下方顯示旋轉角度，長按開關則恢復原狀";
