MSG.title = "Webduino Blockly Chapter 8-1 : Button control servo motor";
MSG.subTitle = "Chapter 8-1 : Button control servo motor";
MSG.demoDescription = "Click on the button to make servo motor to the corresponding angle";