MSG.title = "Webduino Blockly Chapter 3-6 : Ultrasonic and Youtube";
MSG.subTitle = "Chapter 3-6 : Ultrasonic and Youtube";
MSG.demoDescription = "Using Ultrasonic sensors, control youtube speed.";
