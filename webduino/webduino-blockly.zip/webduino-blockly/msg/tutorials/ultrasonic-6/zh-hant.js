MSG.title = "Webduino Blockly 課程 3-6：超音波傳感器控制 Youtube 播放速度";
MSG.subTitle = "課程 3-6：超音波傳感器控制 Youtube 播放速度";
MSG.demoDescription = "使用超音波傳感器，控制 youtube 的速度變化。";
