MSG.title = "Webduino Blockly Chapter 12-2 : LED light use photoresistors";
MSG.subTitle = "Chapter 12-2 : LED light use photoresistors";
MSG.demoDescription = "Use photoresistors, return values and light LED lamp with bulb picture below.";
