MSG.title = "Webduino Blockly 課程 12-2：使用光敏電阻點亮 LED 燈";
MSG.subTitle = "課程 12-2：使用光敏電阻點亮 LED 燈";
MSG.demoDescription = "使用光敏電阻，回傳數值，點亮 LED 燈與下面的燈泡圖片";
