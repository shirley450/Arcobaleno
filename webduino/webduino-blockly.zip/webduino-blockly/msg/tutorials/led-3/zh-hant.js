MSG.title = "Webduino Blockly 課程 1-3：控制兩顆 LED 燈";
MSG.subTitle = "課程 1-3：控制兩顆 LED 燈";
MSG.demoDescription = "點選下圖左右兩顆燈泡，分別控制兩顆 LED 的開或關";
