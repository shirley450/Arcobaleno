MSG.title = "Webduino Blockly Chapter 1-3 : Control 2 LED";
MSG.subTitle = "Chapter 1-3 : Control 2 LED";
MSG.demoDescription = "Click on the two light bulbs, control of two LED on or off";
