MSG.title = "Webduino Blockly 課程 1-2：點選圖片控制 LED 燈";
MSG.subTitle = "課程 1-2：點選圖片控制 LED 燈";
MSG.demoDescription = "點選下圖的燈泡，控制 LED 的開或關";
