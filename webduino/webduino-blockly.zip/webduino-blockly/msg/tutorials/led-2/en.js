MSG.title = "Webduino Blockly Chapter 1-2 : Click the image control LED";
MSG.subTitle = "Chapter 1-2 : Click the image control LED";
MSG.demoDescription = "Click on the image below the bulb and the control LED on or off";
