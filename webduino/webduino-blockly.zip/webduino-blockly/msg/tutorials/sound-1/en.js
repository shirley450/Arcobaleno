MSG.title = "Webduino Blockly Chapter 6-1 : Sound detect";
MSG.subTitle = "Chapter 6-1 : Sound detect";
MSG.demoDescription = "If it detects sound, let the bulb light";
