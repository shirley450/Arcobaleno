MSG.title = "Webduino Blockly 課程 7-1：偵測聲音";
MSG.subTitle = "課程 7-1：偵測聲音";
MSG.demoDescription = "偵測到聲音，就讓圖片的燈泡發亮";
