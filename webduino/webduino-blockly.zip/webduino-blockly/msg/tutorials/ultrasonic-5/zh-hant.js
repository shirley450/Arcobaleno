MSG.title = "Webduino Blockly 課程 3-5：超音波傳感器控制 Youtube 音量";
MSG.subTitle = "課程 3-5：超音波傳感器控制 youtube 的音量";
MSG.demoDescription = "使用超音波傳感器，控制 youtube 的音量變化，越靠近越小聲，越遠越大聲。";
