MSG.title = "Webduino Blockly 課程 3-3：超音波傳感器改變音量大小";
MSG.subTitle = "課程 3-3：超音波傳感器改變音量大小";
MSG.demoDescription = "使用超音波傳感器改變音樂的音量大小";
