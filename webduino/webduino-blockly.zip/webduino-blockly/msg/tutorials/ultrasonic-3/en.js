MSG.title = "Webduino Blockly Chapter 3-3 : UltraSonic change the volume of the music";
MSG.subTitle = "Chapter 3-3 : UltraSonic change the volume of the music";
MSG.demoDescription = "Using Ultrasonic sensors, changing the volume of the music";
