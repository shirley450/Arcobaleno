MSG.title = "Webduino Blockly 課程 4-3：點擊按鈕開關改變圖片位置";
MSG.subTitle = "課程 4-3：點擊按鈕開關改變圖片位置";
MSG.demoDescription = "透過點擊按鈕開關，讓圖片的位置改變";
