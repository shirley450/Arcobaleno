MSG.title = "Webduino Blockly Chapter 4-3 : Click button to change image position";
MSG.subTitle = "Chapter 4-3 : Click button to change image position";
MSG.demoDescription = "By clicking the button to change the position of picture";
