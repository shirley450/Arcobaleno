MSG.title = "Webduino Blockly Chapter 14-1 : Tri-axis accelerometer";
MSG.subTitle = "Chapter 14-1 : Tri-axis accelerometer";
MSG.demoDescription = "Tri-axis accelerometer, returned rotation value.";
