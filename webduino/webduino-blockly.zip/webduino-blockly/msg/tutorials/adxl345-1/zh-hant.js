MSG.title = "Webduino Blockly 課程 14-1：控制三軸加速度計";
MSG.subTitle = "課程 14-1：控制三軸加速度計";
MSG.demoDescription = "控制三軸加速度計，回傳旋轉數值";
