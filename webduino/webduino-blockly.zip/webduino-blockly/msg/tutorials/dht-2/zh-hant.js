MSG.title = "Webduino Blockly 課程 5-2：繪製溫濕度圖表";
MSG.subTitle = "課程 5-2：繪製溫濕度圖表";
MSG.demoDescription = "使用溫濕度傳感器，利用溫度與濕度繪製視覺化圖表";
MSG.temperature = "溫度：";
MSG.humidity = "濕度：";
