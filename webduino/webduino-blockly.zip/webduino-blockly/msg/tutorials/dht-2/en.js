MSG.title = "Webduino Blockly Chapter 5-2: Draw Area Chart";
MSG.subTitle = "Chapter 5-2: Draw Area Chart";
MSG.demoDescription = "Use DHT sensor, and draw area chart";
MSG.temperature = "temperature: ";
MSG.humidity = "humidity: ";
