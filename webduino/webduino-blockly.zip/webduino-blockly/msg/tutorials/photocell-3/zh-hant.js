MSG.title = "Webduino Blockly 課程 12-3：轉換光敏 ( 可變 ) 電阻數值";
MSG.subTitle = "課程 12-3：轉換光敏 ( 可變 ) 電阻數值";
MSG.demoDescription = "利用數值轉換積木，將光敏 ( 可變 ) 電阻輸入的數值轉換為固定的區間數值";
