MSG.title = "Webduino Blockly Chapter 12-3 : Convert photocell (variable) value";
MSG.subTitle = "Chapter 12-3 : Convert photocell (variable) value";
MSG.demoDescription = "Using numeric conversion blocks, photosensitive (variable) resistor input converted to a fixed range of values.";
