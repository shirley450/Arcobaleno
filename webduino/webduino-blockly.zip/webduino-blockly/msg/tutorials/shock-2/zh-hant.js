MSG.title = "Webduino Blockly 課程 10-2：震動按鈕開關改變圖片位置";
MSG.subTitle = "課程 10-2：震動按鈕開關改變圖片位置";
MSG.demoDescription = "透過晃動震動開關，讓圖片的位置改變";
