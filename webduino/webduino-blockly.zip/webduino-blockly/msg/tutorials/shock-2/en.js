MSG.title = "Webduino Blockly Chapter 10-2 : Shock button to change image position";
MSG.subTitle = "Chapter 10-2 : Shock button to change image position";
MSG.demoDescription = "By shocking the shock button to change the position of picture";
