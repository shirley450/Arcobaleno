MSG.title = "Webduino Blockly Chapter 6-1 : Sound detect and light LED";
MSG.subTitle = "Chapter 6-1 : Sound detect and light LED";
MSG.demoDescription = "If it detects sound, let the bulb and LED light";
