MSG.title = "Webduino Blockly 課程 7-2：偵測聲音點亮 LED 燈";
MSG.subTitle = "課程 7-2：偵測聲音點亮 LED 燈";
MSG.demoDescription = "偵測到聲音，讓圖片的燈泡發亮，並點亮 LED 燈";
