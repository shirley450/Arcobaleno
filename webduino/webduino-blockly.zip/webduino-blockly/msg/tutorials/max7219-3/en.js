MSG.title = "Webduino Blockly Chapter 13-3 : Matrix marquee effect";
MSG.subTitle = "Chapter 13-3 : Matrix marquee effect";
MSG.demoDescription = "Use dot matrix marquee effect, you can click on the following link graphic codes.";
