MSG.title = "Webduino Blockly 課程 13-3：點矩陣跑馬燈效果";
MSG.subTitle = "課程 13-3：點矩陣跑馬燈效果";
MSG.demoDescription = "利用點矩陣做出跑馬燈效果，可以點選下面的連結產生圖形代碼";
