MSG.title = "Webduino Blockly 課程 11-2：點選圖片控制繼電器";
MSG.subTitle = "課程 11-2：點選圖片控制繼電器";
MSG.demoDescription = "點選下圖的燈泡，控制繼電器的開或關";
