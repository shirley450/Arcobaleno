MSG.title = "Webduino Blockly Chapter 1-2 : Click the image control Relay";
MSG.subTitle = "Chapter 1-2 : Click the image control Relay";
MSG.demoDescription = "Click on the image below the bulb and the control Relay on or off";
