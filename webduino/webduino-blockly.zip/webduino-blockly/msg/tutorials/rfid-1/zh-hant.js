MSG.title = "Webduino Blockly 課程 16-1：偵測 RFID";
MSG.subTitle = "課程 16-1：偵測 RFID";
MSG.demoDescription = "更換不同的感應卡或磁扣，偵測並顯示 RFID 的代碼";
