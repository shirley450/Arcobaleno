MSG.title = "Webduino Blockly Chapter 16-1 : RFID";
MSG.subTitle = "Chapter 16-1 : RFID";
MSG.demoDescription = "Show RFID's code when you changed diffrent RFID card.";
