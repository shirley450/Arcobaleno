MSG.title = "Webduino Blockly 課程 6-2：偵測人體紅外線點亮 LED 燈";
MSG.subTitle = "課程 6-2：偵測人體紅外線點亮 LED 燈";
MSG.demoDescription = "偵測到人體紅外線變化時，讓圖片的燈泡發亮，並點亮 LED 燈";
