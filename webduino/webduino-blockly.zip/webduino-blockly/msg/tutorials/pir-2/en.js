MSG.title = "Webduino Blockly Chapter 6-2 : PIR and LED";
MSG.subTitle = "Chapter 6-2 : PIR and LED";
MSG.demoDescription = "If it detects human infra-red change light bulb and LED glows";
