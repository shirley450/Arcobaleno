MSG.title = "Webduino Blockly Chapter 13-2 : Matrix animation";
MSG.subTitle = "Chapter 13-2 : Matrix animation";
MSG.demoDescription = "Use dot matrix animation, you can click on the following link graphic codes.";
