MSG.title = "Webduino Blockly 課程 13-2：點矩陣製作動畫";
MSG.subTitle = "課程 13-2：點矩陣製作動畫";
MSG.demoDescription = "利用點矩陣製作動畫，可以點選下面的連結產生圖形代碼";
