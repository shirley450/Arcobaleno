MSG.title = "Webduino Blockly Chapter 13-5 : Ultrasonic and Matrix";
MSG.subTitle = "Chapter 13-5 : Ultrasonic and Matrix";
MSG.demoDescription = "Using ultrasonic sensor change dot-matrix graphics. (You can click on the following link graphic codes).";
