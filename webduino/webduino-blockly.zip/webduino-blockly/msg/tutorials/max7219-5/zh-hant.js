MSG.title = "Webduino Blockly 課程 13-5：利用超音波傳感器改變點矩陣圖形";
MSG.subTitle = "課程 13-5：利用超音波傳感器改變點矩陣圖形";
MSG.demoDescription = "利用超音波傳感器改變點矩陣圖形。( 可以點選下面的連結產生圖形代碼 )";
