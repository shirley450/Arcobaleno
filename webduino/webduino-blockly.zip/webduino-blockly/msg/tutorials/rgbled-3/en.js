MSG.title = "Webduino Blockly Chapter 2-3：RGB LED Palette";
MSG.subTitle = "Chapter 2-3：RGB LED Palette";
MSG.demoDescription = "Using the range, making RGB LED palette";
