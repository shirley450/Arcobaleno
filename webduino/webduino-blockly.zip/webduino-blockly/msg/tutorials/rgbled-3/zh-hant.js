MSG.title = "Webduino Blockly 課程 2-3：三色 LED 燈調色盤";
MSG.subTitle = "課程 2-3：三色 LED 燈調色盤";
MSG.demoDescription = "利用拉霸，調整三色 LED 燈的顏色";
