MSG.title = "Webduino Blockly 課程 2-4：轉吧七彩霓虹燈";
MSG.subTitle = "課程 2-4：轉吧七彩霓虹燈";
MSG.demoDescription = "利用燈泡圖片作為開關，讓三色 LED 燈有不同顏色的呈現";
