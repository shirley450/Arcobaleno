MSG.title = "Webduino Blockly Chapter 2-4：Colorful lights";
MSG.timerVariable = "timer";
MSG.subTitle = "Chapter 2-4：Colorful lights";
MSG.demoDescription = "Click on the light bulb, let the RGB LED become colorful lights";
