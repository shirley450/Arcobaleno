MSG.title = "Webduino Blockly Chapter 14-4 : Three-axis and Matrix";
MSG.subTitle = "Chapter 14-4 : Three-axis and Matrix";
MSG.demoDescription = "Tri-axis accelerometer, returned rotation value, change the dot matrix graphic.";
