MSG.title = "Webduino Blockly Chapter 11-1 : Relay";
MSG.subTitle = "Chapter 11-1 : Relay";
MSG.demoDescription = "Using blocks to control relay";
