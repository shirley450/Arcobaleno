MSG.title = "Webduino Blockly 課程 11-1：控制繼電器";
MSG.subTitle = "課程 11-1：控制繼電器";
MSG.demoDescription = "控制繼電器，並將狀態由燈泡圖片顯示";
