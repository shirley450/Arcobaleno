MSG.title = "Webduino Blockly 課程 14-3：旋轉角度點亮 LED 燈";
MSG.subTitle = "課程 14-3：旋轉角度點亮 LED 燈";
MSG.demoDescription = "控制三軸加速度計，回傳旋轉數值，點亮 LED 燈";
