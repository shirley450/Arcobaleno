MSG.title = "Webduino Blockly Chapter 14-3 : Three-axis and LED";
MSG.subTitle = "Chapter 14-3 : Three-axis and LED";
MSG.demoDescription = "Tri-axis accelerometer, returned rotation value, LED light points.";
