MSG.title = "Webduino Blockly 課程 16-3：RFID 控制 Youtube";
MSG.subTitle = "課程 16-3：RFID 控制 Youtube";
MSG.demoDescription = "利用 RFID 控制 Youtube 的播放";
