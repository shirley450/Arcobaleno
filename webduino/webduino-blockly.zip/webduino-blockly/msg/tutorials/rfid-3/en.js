MSG.title = "Webduino Blockly Chapter 16-3 : RFID and Youtube";
MSG.subTitle = "Chapter 16-3 : RFID and Youtube";
MSG.demoDescription = "Using RFID to control Youtube.";
