MSG.title = "Webduino Blockly Chapter 16-2 : RFID and RGB LED";
MSG.subTitle = "Chapter 16-2 : RFID and RGB LED";
MSG.demoDescription = "Using RFID to control RGB LED light colors.";
