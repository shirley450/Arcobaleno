MSG.title = "Webduino Blockly 課程 16-2：RFID 紅綠燈";
MSG.subTitle = "課程 16-2：RFID 紅綠燈";
MSG.demoDescription = "利用 RFID 控制三色 LED 燈的顏色切換";
