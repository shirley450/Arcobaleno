MSG.title = "Webduino Blockly Chapter 3-1 : UltraSonic";
MSG.subTitle = "Chapter 3-1 : UltraSonic";
MSG.demoDescription = "Using the ultrasonic sensor, return the distance and displays distance.";
