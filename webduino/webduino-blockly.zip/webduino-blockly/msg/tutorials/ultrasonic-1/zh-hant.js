MSG.title = "Webduino Blockly 課程 3-1：超音波傳感器";
MSG.subTitle = "課程 3-1：超音波傳感器";
MSG.demoDescription = "使用超音波傳感器，回傳並顯示偵測到的公分數";
