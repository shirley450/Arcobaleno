MSG.title = "Webduino Blockly Chapter 15-2 : Change color";
MSG.subTitle = "Chapter 15-2 : Change color";
MSG.demoDescription = "Receive infrared signals, different codes, area will display a different color.";
