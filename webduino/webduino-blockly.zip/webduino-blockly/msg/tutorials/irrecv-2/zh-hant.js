MSG.title = "Webduino Blockly 課程 15-2：接收紅外線訊號改變區域顏色";
MSG.subTitle = "課程 15-2：接收紅外線訊號改變區域顏色";
MSG.demoDescription = "接收紅外線訊號，不同的代號，區域會顯示不同顏色";
