MSG.title = "Webduino Blockly Chapter 13-4 : Click button toggles matrix effect";
MSG.subTitle = "Chapter 13-4 : Click button toggles matrix effect";
MSG.demoDescription = "Click on the button, toggle dot-matrix effect. (You can click on the following link graphic codes).";
MSG.btn1 = "Button 1";
MSG.btn2 = "Button 2";
MSG.btn3 = "Button 3";
MSG.btnStop = "Stop";
MSG.btnOff = "Turn off";
