MSG.title = "Webduino Blockly 課程 13-4：點選按鈕切換點矩陣效果";
MSG.subTitle = "課程 13-4：點選按鈕切換點矩陣效果";
MSG.demoDescription = "點選按鈕，切換切換點矩陣效果。( 可以點選下面的連結產生圖形代碼 )";
MSG.btn1 = "按鈕 1";
MSG.btn2 = "按鈕 2";
MSG.btn3 = "按鈕 3";
MSG.btnStop = "停止動畫";
MSG.btnOff = "關閉";
